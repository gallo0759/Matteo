#include <iostream>
#include <fstream>
#include <string>
#include <unistd.h> //per colori
#include <ctime>
#include <cstdlib>

using namespace std;


void mostraMenuIniziale() {
    cout << "___________________________" << endl;
    cout << endl;
    cout << "BENVENUTO IN VITALI WORDLE" << endl;
    cout << "___________________________" << endl;
    cout << endl;
    cout << "1. Apri le informazioni e le regole del gioco" << endl;
    cout << "2. Visualizza i meriti e gli autori del gioco" << endl;
    cout << "3. Inizia a giocare" << endl;
    cout << endl;
    cout << "Seleziona un'opzione: ";

    }

void mostraInformazioniRegole() {
    cout << "Ecco le informazioni e le regole del gioco:" << endl;
    cout<<"SPIEGAZIONE"<<endl;
    cout<<"1. Scegli la lunghezza della parola"<<endl;
    cout<<"2. Inizia con una parola a tua scelta"<<endl;
    cout<<"3. Vedi quante lettere hai indovinato"<<endl;
    cout << "\033[33m" << "giallo" << "\033[0m" <<" la lettera e' presente ma non e' giusta la posizione"<<endl;
    cout << "\033[32m" << "verde" << "\033[0m" <<" la lettera e' presente ed e' alla posizione corretta"<<endl<<endl;
}

void mostraMeritiAutori() {
    cout << "Questo gioco e' stato creato da Vitali Matteo." << endl;
    cout << "Ringraziamo gli autori per il loro lavoro." << endl;
}

string estraiParolaDaFile(int lunghezzaParola) {
    const string nomeFile = "Lista_Parole.txt";
    ifstream file(nomeFile);
    string parola;
    int count = 0;
    int randomIndex = 0;

    if (file.is_open()) {
        while (file >> parola) {
            if (parola.length() == lunghezzaParola) {
                ++count;
            }
        }
        file.close();

        srand(time(0));
        randomIndex = rand() % count;

        file.open(nomeFile);
        count = 0;

        while (file >> parola) {
            if (parola.length() == lunghezzaParola) {
                if (count == randomIndex) {
                    file.close();
                    return parola;
                }
                ++count;
            }
        }
        file.close();
    } else {
        cerr << "Impossibile aprire il file " << nomeFile << endl;
    }

    return "";
}


bool indovinaParola(const string& parolaEstratta) {
    const int maxTentativi = 7;
    int tentativiRimasti = maxTentativi;
    string ipotesi;

    while (tentativiRimasti > 0) {
        cout << "Indovina la parola (tentativi rimanenti: " << tentativiRimasti << "): ";
        cin >> ipotesi;

        if (ipotesi == parolaEstratta) {
            cout << "Complimenti! Hai indovinato la parola: " << parolaEstratta << endl;
            return true;
        } else {
            cout << "Parola errata. ";


            for (size_t i = 0; i < parolaEstratta.length(); ++i) {
                if (i < ipotesi.length() && ipotesi[i] == parolaEstratta[i]) {
                    cout << "\033[32m" << ipotesi[i] << "\033[0m";
                } else if (parolaEstratta.find(ipotesi[i]) != string::npos) {
                    cout << "\033[33m" << ipotesi[i] << "\033[0m";
                } else {
                    cout << "_";
                }
            }
            cout << endl;

            tentativiRimasti--;
        }
    }

    cout << "Mi dispiace, hai esaurito tutti i tentativi. La parola corretta era: " << parolaEstratta << endl;
    return false;
}

int main() {
    int scelta;
    bool finito=false;
    mostraMenuIniziale();
    cin >> scelta;
    switch (scelta) {
        case 1:
            mostraInformazioniRegole();
            break;
        case 2:
            mostraMeritiAutori();
            break;
        case 3:
            int lunghezzaParola;
            do {
                cout << "Inserisci la lunghezza della parola da indovinare (da 3 a 10): ";
                cin >> lunghezzaParola;
            } while (lunghezzaParola < 3 || lunghezzaParola > 10);

            string parolaEstratta = estraiParolaDaFile(lunghezzaParola);

            if (!parolaEstratta.empty()) {
                indovinaParola(parolaEstratta);
            } else {
                cout << "Nessuna parola di lunghezza " << lunghezzaParola << " trovata nel file." << endl;
            }
            break;
            cout << "Selezione non valida. Per favore, scegli un'opzione valida." << endl;
    }

    return 0;
}
